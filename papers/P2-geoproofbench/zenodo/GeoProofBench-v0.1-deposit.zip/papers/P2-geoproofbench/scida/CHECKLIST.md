# Scientific Data 投稿对照清单（Data Descriptor）

依据：<https://www.nature.com/sdata/publish/submission-guidelines>
（2026-09-06 抓取）。期刊**不提供、也不建议**用任何 LaTeX 模板；强制的是第 1 节的小标题。

本目录已生成的首轮包：

| 文件 | 用途 |
|---|---|
| `geoproofbench.pdf` | **首轮最省事**：主文 + 图 + 表，一篇 PDF |
| `geoproofbench.tex` | 修订轮要交的独立 `.tex`（参考文献已内嵌，无 `.bib`） |
| `figures/fig1–fig4.png` | 从 manim mp4 末帧抽出的静图 |
| `cover_letter.md` | 系统要求上传的 covering letter（可几乎空白；现有信可传） |

本地编译：`pdflatex geoproofbench.tex` 两次。

---

## A. 不补就很难过编辑部初检（先做）

1. **审稿人可匿名下载的数据包 URL**  
   首轮明确要求：任意可匿名下载的链接即可（云盘 / ScienceDB / Zenodo 均可），不必已是最终 DOI。  
   现在只有本地 `papers/P2-geoproofbench/zenodo/GeoProofBench-v0.1-deposit.zip`，**没有对外 URL**。  
   正文 Data Availability 已写明“DOI not yet minted”。  
   **建议**：ScienceDB（`scidb.cn`）Restricted + 审稿链接，或网盘（到期前勿删）。

2. **不要把现在的 `manuscript.md` 当投稿文件**  
   现稿是实验室 IMRaD + 中英混排笔记（Introduction / Related Work / Experiments / Conclusion），**不是** Data Descriptor 强制结构。  
   请投 `scida/geoproofbench.pdf`（或由其 `.tex` 出的 PDF）。

3. **SNAPP 网页表单（和 PDF 同等重要）**  
   - Article type = **Data Descriptor**（不是 Article）  
   - 作者、单位、通讯邮箱、ORCID  
   - Funding（无外部经费也要勾）  
   - Competing interests = No  
   - Author contributions（单作者也要填）  
   - Data / Code 访问说明（填审稿 URL）  
   - APC / 是否申请减免（不要写在 cover letter）  
   - 相关已发表工作：勾选并引用 SAM-GFNet（不共享数据）

---

## B. 指南硬性格式（已在 `.tex` 里改过的 vs 原稿仍错的）

| 条款 | 指南 | 原稿 `manuscript.md` | 本包 `.tex` |
|---|---|---|---|
| 标题 ≤110 字符、**禁止冒号/括号**、避免自造品牌名 | 强制 | 有冒号；含 GeoProofBench | 70 字符，无冒号 |
| Abstract ≤170 词、不写新科学发现、不放 URL | 建议/实质 | 248 词 | 153 词 |
| 强制小标题 | Background \& Summary, Methods, Data Records, Technical Validation, Usage Notes（可选）, Data Availability, Code Availability, References | Introduction / Related Work / Experiments / Conclusion | 已对齐 |
| Data Overview | 可选，1–2 图/表 + 一段 | 无此节；附录很长 | 两表，短 |
| 结论/分析结果 | Data Descriptor **不要** | §9–§10 有 Discussion/Conclusion | 已去掉 |
| 引用编号、DOI、参考文献嵌在 `.tex` | 强制（修订轮） | 无正式参考文献表 | `thebibliography` 内嵌 |
| 图 ≤8、表 ≤10 | 建议 | 只有 mp4 | 4 图 3 表 |
| 首轮可只交 PDF | 允许 | — | 已编译 9 页 PDF |

---

## C. 还需要补全或核对的内容（建议在投稿前改 `.tex`）

4. **数据集 DOI / 数据引用**  
   现在 References 里 `datasetpending` 是占位。铸 DOI 后：在正文用上标引用，References 写成仓库记录上的作者 + 标题 + 年 + `https://doi.org/...`。

5. **Guo et al. Remote Sensing 2025（SAM-GFNet）缺完整页码/DOI**  
   指南要求能找到的条目尽量带 DOI。请用正式书目替换 `\bibitem{guo2025sam}`。

6. **“五十条命题、六条已实现”** 与仓库实际条目  
   请确认 `benchmark/` 与 `formal/` 一致，避免审稿人按 GPB-050 去找空文件。

7. **Cover letter 与正文数字不一致**  
   信里仍写 lake **2760** modules；P-COMP-5 后是 **2764**。投出前改信，或投极简 cover letter（期刊说封面信不参与录用判断）。

8. **静图质量**  
   现图为 854×480 mp4 末帧，字小。修订轮建议：用更高分辨率导出、sans-serif、白底、每图一个文件、多面板合成单张（指南 Figures for publication）。  
   动画 mp4 放数据包，不要当正文 Figure。

9. **Data Records 再写细一点**  
   指南希望：仓库、文件格式、目录、需要解释的字段名。可把 `FILELIST.md` 缩成一表放进 Data Records。

10. **3DEP ImageServer 与“真实产品”表述**  
    正文已说明 S3 COG 不可达、改走 ImageServer。投稿前确认 ScienceDB/zip 里**没有**把合成 SRTM/LiDAR 标成真产品。

11. **语言润色**  
    期刊几乎不做 copy-edit。可考虑 Nature Research Editing 或同等服务（自费、不保证送审）。

12. **双盲**  
    Scientific Data **不是**双盲：作者姓名留在稿上即可。Acknowledgements 已写 Removed for review，接收后可补。

---

## D. 首轮系统上传建议清单

上传（SNAPP）：

- [ ] Article file：`geoproofbench.pdf`（首轮）  
- [ ] Covering letter：`cover_letter.md` 或导出 PDF（系统强制有文件）  
- [ ] 审稿数据链接：填在系统 **和** 正文 Data Availability（封面信里的数据说明审稿人看不到）  
- [ ] 可选：Suggested / non-preferred reviewers  

不要首轮就传：独立图文件、`.zip` 的 tex 工程、Supplementary（能放正文就放正文）。

修订轮再交：独立 `.tex`、每图一个 PNG/TIFF、Response to Reviewers。

---

## E. 明确不必做的事

- 不要用 Springer Nature / Overleaf 旧 SciDA 模板，不要用其他期刊模板。  
- 不要另附 `.bib` / `.bbl`。  
- 不要把 lake 缓存打进数据包。  
- 不要把 GitHub 私有仓当作唯一数据仓储（无 DOI，且现仍禁止 push）。  
- 不要在 cover letter 里写重要性、APC、数据下载步骤。

---

## F. 建议投稿顺序

1. 把 zip 传到 ScienceDB（或可匿名下载的网盘），拿到审稿 URL。  
2. 把 URL 写进 `geoproofbench.tex` Data Availability，重编译 PDF。  
3. 统一 cover letter 里的 lake 模块数。  
4. SNAPP 选 Data Descriptor，传 PDF + covering letter。  
5. DOI 铸好后改 Data Availability + References，作为修订或校样更新。
